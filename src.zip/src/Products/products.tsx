import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./products.css";

interface Produto {
  id: number;
  nome: string;
  preco: number;
}

const Products = () => {
  const [produtos, setProdutos] = useState<Produto[]>([
    { id: 1, nome: "Arroz 5kg", preco: 25.90 },
    { id: 2, nome: "Feijão 1kg", preco: 8.50 },
    { id: 3, nome: "Leite 1L", preco: 5.20 },
  ]);

  const [nome, setNome] = useState("");
  const [preco, setPreco] = useState<number | string>("");
  const [editando, setEditando] = useState<number | null>(null);

  // Função para cadastrar novo produto
  const adicionarProduto = (e: React.FormEvent) => {
    e.preventDefault();

    if (!nome || !preco) {
      alert("Preencha todos os campos!");
      return;
    }

    if (editando !== null) {
      // Editar produto existente
      const produtosAtualizados = produtos.map((p) =>
        p.id === editando ? { ...p, nome, preco: Number(preco) } : p
      );
      setProdutos(produtosAtualizados);
      setEditando(null);
      alert("Produto atualizado com sucesso!");
    } else {
      // Adicionar novo produto
      const novoProduto = {
        id: produtos.length > 0 ? produtos[produtos.length - 1].id + 1 : 1,
        nome,
        preco: Number(preco),
      };
      setProdutos([...produtos, novoProduto]);
      alert("Produto cadastrado com sucesso!");
    }

    setNome("");
    setPreco("");
  };

  // Função para editar um produto existente
  const editarProduto = (produto: Produto) => {
    setEditando(produto.id);
    setNome(produto.nome);
    setPreco(produto.preco);
  };

  // Função para remover um produto
  const removerProduto = (id: number) => {
    if (confirm("Deseja realmente remover este produto?")) {
      const listaAtualizada = produtos.filter((p) => p.id !== id);
      setProdutos(listaAtualizada);
    }
  };

  return (
    <div className="products-page">
      {/* Navbar */}
      <nav className="navbar">
        <ul>
          <li><Link to="/products">Produtos</Link></li>
          <li><Link to="/promotion">Promoções</Link></li>
          <li><Link to="/users">Usuários</Link></li>
          <li><Link to="/editusers">Editar Usuários</Link></li>
          <li><Link to="/login" className="logout">Sair</Link></li>
        </ul>
      </nav>

      {/* Formulário de cadastro */}
      <div className="form-container">
        <h1>{editando ? "Editar Produto" : "Cadastrar Produto"}</h1>
        <form onSubmit={adicionarProduto}>
          <input
            type="text"
            placeholder="Nome do produto"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
          />
          <input
            type="number"
            placeholder="Preço"
            value={preco}
            onChange={(e) => setPreco(e.target.value)}
          />
          <button type="submit">
            {editando ? "Salvar Alterações" : "Cadastrar"}
          </button>
          {editando && (
            <button
              type="button"
              className="cancelar"
              onClick={() => {
                setEditando(null);
                setNome("");
                setPreco("");
              }}
            >
              Cancelar
            </button>
          )}
        </form>
      </div>

      {/* Lista de produtos */}
      <div className="products-container">
        <h2>Lista de Produtos</h2>
        {produtos.length === 0 ? (
          <p>Nenhum produto cadastrado.</p>
        ) : (
          <table className="products-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Preço (R$)</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {produtos.map((produto) => (
                <tr key={produto.id}>
                  <td>{produto.id}</td>
                  <td>{produto.nome}</td>
                  <td>{produto.preco.toFixed(2)}</td>
                  <td>
                    <button
                      className="btn-edit"
                      onClick={() => editarProduto(produto)}
                    >
                      Editar
                    </button>
                    <button
                      className="btn-delete"
                      onClick={() => removerProduto(produto.id)}
                    >
                      Remover
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Products;