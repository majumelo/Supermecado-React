import { useState } from "react";
import "./login.css";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigation = useNavigate();

  const sendRequest = async (e: any) => {
    e.preventDefault();

    if (!username || !password ) {
      alert("Preencha todos os campos para continuar.");
      return;
    } else if(username !== "" && password !== "") {
      alert("Login realizado com sucesso!");
      alert(`Bem-vindo ao Mercadinho Unifacisa ${username}`);
      navigation('/products');
    }
};

  return (
    <div id="login-page">
      <div id="login-form-container">
        <h1>Mercadinho Unifacisa</h1>
        <p>Somente para Funcionários</p>

        <form id="login-form" onSubmit={(event) => {sendRequest(event)}}>
          <input
            type="username" id="username" placeholder="Usuário" value={username} onChange={(e) => setUsername(e.target.value)}  autoComplete="username"
          />
          <input type="password" id="password" placeholder="Senha" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password"
          />

          <div className="options">
            <a href="#">Esqueceu a senha?</a>
          </div>

          <button type="submit">ENTRAR</button>
        </form>

      </div>
    </div>
  );
};

export default Login;