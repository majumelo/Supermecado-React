import { useState } from "react";
import { Link } from "react-router-dom";
import "./promotion.css";

interface Produto {
  id: number;
  nome: string;
  preco: number;
  promocaoAtiva?: boolean;
  precoPromocional?: number;
}

const Promotion = () => {
  const [produtos, setProdutos] = useState<Produto[]>([
    { id: 1, nome: "Chocolate Lacta 90g", preco: 7.5 },
    { id: 2, nome: "Biscoito Trakinas", preco: 4.0 },
    { id: 3, nome: "Refrigerante Coca-Cola 2L", preco: 10.0 },
  ]);

  const [desconto, setDesconto] = useState<number | string>("");
  const [produtoSelecionado, setProdutoSelecionado] = useState<number | null>(null);

  // Função para aplicar promoção
  const aplicarPromocao = (id: number) => {
    if (!desconto || Number(desconto) <= 0) {
      alert("Informe um valor de desconto válido!");
      return;
    }

    const produtosAtualizados = produtos.map((p) => {
      if (p.id === id) {
        const precoPromocional = p.preco - (p.preco * Number(desconto)) / 100;
        return {
          ...p,
          promocaoAtiva: true,
          precoPromocional: Number(precoPromocional.toFixed(2)),
        };
      }
      return p;
    });

    setProdutos(produtosAtualizados);
    setDesconto("");
    setProdutoSelecionado(null);
    alert("Promoção aplicada com sucesso!");
  };

  // Função para remover promoção
  const removerPromocao = (id: number) => {
    const produtosAtualizados = produtos.map((p) =>
      p.id === id ? { ...p, promocaoAtiva: false, precoPromocional: undefined } : p
    );
    setProdutos(produtosAtualizados);
    alert("Promoção removida!");
  };

  return (
    <div className="promotion-page">
      {/* Navbar */}
      <nav className="navbar">
        <ul>
          <li><Link to="/products">Produtos</Link></li>
          <li><Link to="/promotion">Promoções</Link></li>
          <li><Link to="/users">Usuários</Link></li>
          <li><Link to="/editusers">Editar Usuários</Link></li>
          <li><Link to="/login" className="logout">Sair</Link></li>
        </ul>
      </nav>

      {/* Conteúdo principal */}
      <div className="promotion-container">
        <h1>Gerenciar Promoções</h1>
        <p>Selecione um produto para aplicar ou remover uma promoção.</p>

        <table className="promotion-table">
          <thead>
            <tr>
              <th>Produto</th>
              <th>Preço</th>
              <th>Preço Promocional</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {produtos.map((p) => (
              <tr key={p.id}>
                <td>{p.nome}</td>
                <td>R$ {p.preco.toFixed(2)}</td>
                <td>
                  {p.promocaoAtiva
                    ? `R$ ${p.precoPromocional?.toFixed(2)}`
                    : "-"}
                </td>
                <td>{p.promocaoAtiva ? "Ativa" : "Nenhuma"}</td>
                <td>
                  {!p.promocaoAtiva ? (
                    <>
                      {produtoSelecionado === p.id ? (
                        <>
                          <input
                            type="number"
                            placeholder="%"
                            value={desconto}
                            onChange={(e) => setDesconto(e.target.value)}
                            className="input-desconto"
                          />
                          <button
                            className="btn-apply"
                            onClick={() => aplicarPromocao(p.id)}
                          >
                            Aplicar
                          </button>
                          <button
                            className="btn-cancel"
                            onClick={() => {
                              setProdutoSelecionado(null);
                              setDesconto("");
                            }}
                          >
                            Cancelar
                          </button>
                        </>
                      ) : (
                        <button
                          className="btn-edit"
                          onClick={() => setProdutoSelecionado(p.id)}
                        >
                          Aplicar Promoção
                        </button>
                      )}
                    </>
                  ) : (
                    <button
                      className="btn-delete"
                      onClick={() => removerPromocao(p.id)}
                    >
                      Remover Promoção
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {produtos.length === 0 && (
          <p className="empty-state">Nenhum produto cadastrado.</p>
        )}
      </div>
    </div>
  );
};

export default Promotion;